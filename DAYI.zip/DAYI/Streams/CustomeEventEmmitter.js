// Create a method that returns an event emitter instance
// biz logic for emitting events
        // event for data
        // event for error
        // event for completion
// subscribe on the events

var EventEmitter  =require('events').EventEmitter;
// pub
function GetIterationCount(maxIteration){
    var e = new EventEmitter();
    // biz logic
    process.nextTick(function(){
        var count = 0;
       var timerId = setInterval(function(){
            e.emit('count',++count); // emit of data !
            if(count == maxIteration){
                e.emit('finish');
                clearInterval(timerId);
            }
            if(count == 8){
                e.emit('error',count);
                clearInterval(timerId);
            }
        },1000)
    });
    return e;
}
// sub
var evt = GetIterationCount(10);

evt.on('count',function(cnt){
    console.log('Received : ' + cnt)
});
evt.on('error',function(lastCnt){
    console.log('Error Encountered ' + lastCnt)
});

evt.on('finish',function(){
    console.log('Done iterating..')
});

console.log('Program ended..')