var fs = require('fs');
// Non - blocking
fs.readFile('Data.txt',function(err,dataFromTheFile){
        if(err){
            console.log('Error  : ' + err);
        }else{
            console.log('Reading File (Async) : ' + dataFromTheFile.toString())
        }
});
// Blocking way !
// var content = fs.readFileSync('Data.txt','UTF-8');
// console.log(content.toString())
 console.log('Program ended..');