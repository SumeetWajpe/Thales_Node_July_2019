var request = require('request');
var fs = require('fs');

var EvtEmtr = request('http://www.google.com');

var response = "";
EvtEmtr.on('data',function(chunk){
    console.log('>>>>>>>>>>>>>> RECEIVED CHUNK >>>>>>>>>>>')
        response += chunk;
});

EvtEmtr.on('end',function(){
    console.log('>>>>>>>>>>>>>> WRITTING CHUNK >>>>>>>>>>>')

    fs.writeFile('GoogleResponse.html',response,function(err){
       if(err){
        console.log(err)
       }       
      
    })
});
