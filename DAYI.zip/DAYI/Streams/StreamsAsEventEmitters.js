var fs = require('fs');

var readableStream = fs.createReadStream('Input.txt');
var writableStream = fs.createWriteStream('Output.txt');
var allData = "";
readableStream.setEncoding("UTF-8");
readableStream.on('data',function(chunk){
    console.log(chunk)
        allData += chunk;
});

readableStream.on('end',function(){
    writableStream.write(allData);
    writableStream.end(); // end the writing
});

