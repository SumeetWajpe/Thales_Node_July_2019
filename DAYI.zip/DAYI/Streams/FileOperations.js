var fs = require('fs');

fs.mkdir('temp',function(err){
    if(err){
        console.log(err);
    }else{
        fs.exists('temp',function(exists){
            if(exists){
                process.chdir('temp');
                fs.writeFile(
                    'Test.txt',
                'This is written using fs.writeFile()',
                function(err){
                        if(err){
                            console.log(err)
                        }else{
                            fs.readFile('Test.txt',function(err,data){
                                console.log(data.toString());
                            });
                        }
                })
            }
        })
    }
});

console.log('Program ended..')