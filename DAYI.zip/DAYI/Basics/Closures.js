function OuterFunction(){
    var x = 10;
    return function (){
        console.log(x);
        x = null;
    }
}

var InnerFunction = OuterFunction();
InnerFunction();
InnerFunction();
