function  Addition(x,y){
    return x + y;
}

function Multiplication(x,y){
    return x * y;
}

const PI = 3.14;
// module.exports.Add = Addition;
// module.exports.Product = Multiplication;

module.exports = {
    Add:Addition,
    Multiply:Multiplication
}
