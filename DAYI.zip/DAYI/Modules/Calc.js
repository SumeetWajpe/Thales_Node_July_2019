var MathObj = require("./Math");

console.log(MathObj.Multiply(10,2));