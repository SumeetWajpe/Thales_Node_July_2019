var os = require('os');// built-in module !

var toMB = function(totalBytes){
    return (Math.round((totalBytes/1024/1024)* 100)/100);
}

console.log('Total Memory :' + toMB(os.totalmem()))